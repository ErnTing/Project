<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link" href="logcall.php">Log Call</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="search.php">Update</a>
      </li>
		
		<li class="nav-item">
        <a class="nav-link" href="report.php">Report</a>
      </li>
		<li class="nav-item">
        <a class="nav-link" href="admin.php">Admin</a>
      </li>
		
    </ul>
    
  </div>
</nav>
