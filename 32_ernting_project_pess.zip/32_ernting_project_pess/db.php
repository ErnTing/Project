<?php // define database connection variables as constant
define('DB_USER', "root"); // db user
define('DB_PASSWORD', ""); // db password 
define('DB_DATABASE', "pessdb"); // database name
define('DB_SERVER', "localhost"); // db server
?>
